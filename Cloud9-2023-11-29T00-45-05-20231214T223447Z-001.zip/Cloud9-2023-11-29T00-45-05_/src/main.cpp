/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LDrive_Group         motor_group   1, 3            
// RDrive_Group         motor_group   2, 4            
// Controller1          controller                    
// Wings1               digital_out   A               
// Wings2               digital_out   D               
// Flywheel             motor_group   9, 10           
// shooter              motor         11              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

// Placeholder variables for PID control
int target_position = 0;
int L_motor_output = 0;
int R_motor_output = 0;
int Lefterror = 0;
int Righterror = 0;


// PID constants
double kp = 0.1;
double ki = 0.01;
double kd = 0.05;

// Integral and derivative terms for PID
double L_integral = 0;
double L_derivative = 0;
double L_last_error = 0;

double R_integral = 0;
double R_derivative = 0;
double R_last_error = 0;

// Function to set drivetrain speed
void setDrivetrainSpeed(int left_speed, int right_speed) {
    LDrive_Group.spin(reverse, left_speed, pct);
    RDrive_Group.spin(forward, right_speed, pct);
}

void setTurntrainSpeed(int left_speed, int right_speed) {
    LDrive_Group.spin(forward, left_speed, pct);
    RDrive_Group.spin(forward, right_speed, pct);
}

int LeftgeEncoderValue() {
    return LDrive_Group.position(degrees);
    
}

int RightgeEncoderValue() {
    return LDrive_Group.position(degrees);
   
}


// Function for autonomous PID movement
void DriveautonomousPIDMovement(int target) {
    // Main control loop

    target_position = target;

    while (true) {
        // Placeholder PID calculations
        Lefterror = target_position - LeftgeEncoderValue();  // Adjust based on your encoder reading function
        Righterror = target_position - RightgeEncoderValue();

        // Proportional, integral, and derivative terms
        double Leftproportional = kp * Lefterror;
        L_integral += ki * Lefterror;
        L_derivative = kd * (Lefterror - L_last_error);

        // Calculate motor output
        L_motor_output = Leftproportional + L_integral + L_derivative;

        // Proportional, integral, and derivative terms
        double Rightproportional = kp * Righterror;
        R_integral += ki * Righterror;
        R_derivative = kd * (Righterror - R_last_error);

        // Calculate motor output
        R_motor_output = Rightproportional + R_integral + R_derivative;

        // Calculate motor speeds based on PID output
        int left_motor_speed = L_motor_output;
        int right_motor_speed = R_motor_output;

        // Apply motor speeds to the drivetrain
        setDrivetrainSpeed(left_motor_speed, right_motor_speed);

        // Update last error for the next iteration
        L_last_error = Lefterror;
        R_last_error = Righterror;


        // Check if the target position is reached within a tolerance
        if (abs(Lefterror) < 10 || abs(Righterror) < 10) {
            // Stop the drivetrain when the target position is reached
            setDrivetrainSpeed(0, 0);
            break;
        }

        Brain.Screen.print("Left Encoder: %f", LDrive_Group.position(degrees));
        Brain.Screen.newLine();
        Brain.Screen.print("Right Encoder: %f", RDrive_Group.position(degrees));
    }
}

// Function for autonomous PID movement
void TurnautonomousPIDMovement(int target) {
    // Main control loop

    target_position = target;

    while (true) {
        // Placeholder PID calculations
        Lefterror = target_position - LeftgeEncoderValue();  // Adjust based on your encoder reading function
        Righterror = target_position - RightgeEncoderValue();

        // Proportional, integral, and derivative terms
        double Leftproportional = kp * Lefterror;
        L_integral += ki * Lefterror;
        L_derivative = kd * (Lefterror - L_last_error);

        // Calculate motor output
        L_motor_output = Leftproportional + L_integral + L_derivative;

        // Proportional, integral, and derivative terms
        double Rightproportional = kp * Righterror;
        R_integral += ki * Righterror;
        R_derivative = kd * (Righterror - R_last_error);

        // Calculate motor output
        R_motor_output = Rightproportional + R_integral + R_derivative;

        // Calculate motor speeds based on PID output
        int left_motor_speed = L_motor_output;
        int right_motor_speed = R_motor_output;

        // Apply motor speeds to the drivetrain
        setTurntrainSpeed(left_motor_speed, right_motor_speed);

        // Update last error for the next iteration
        L_last_error = Lefterror;
        R_last_error = Righterror;


        // Check if the target position is reached within a tolerance
        if (abs(Lefterror) < 10 || abs(Righterror) < 10) {
            // Stop the drivetrain when the target position is reached
            setDrivetrainSpeed(0, 0);
            break;
        }

        Brain.Screen.print("Left Encoder: %f", LDrive_Group.position(degrees));
        Brain.Screen.newLine();
        Brain.Screen.print("Right Encoder: %f", RDrive_Group.position(degrees));
    }
}

void autonomous(void) {
  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
  Wings1.set(true);
  Wings2.set(true);
  TurnautonomousPIDMovement(500);
  Wings1.set(false);
  Wings2.set(false);

  shooter.spin(forward, 50, pct);
  wait(1, sec);//so the actual shooter has time to speed up
  Flywheel.spin(forward, 50, pct);

  shooter.spin(forward, 0 ,pct);
  Flywheel.spin(forward, 0 ,pct);

  TurnautonomousPIDMovement(500);
  DriveautonomousPIDMovement(500);

  
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {
    // This is the main execution loop for the user control program.
    // Each time through the loop your program should update motor + servo
    // values based on feedback from the joysticks.

    // ........................................................................
    // Insert user code here. This is where you use the joystick values to
    // update your motors, etc.
    // ........................................................................

    // Set the default velocity of the motors
    //LDrive_Group.setVelocity(50, velocityUnits::pct);
    //RDrive_Group.setVelocity(50, velocityUnits::pct);

    // Making the robot move
    LDrive_Group.spin(forward, Controller1.Axis3.value(), pct);
    RDrive_Group.spin(reverse, Controller1.Axis2.value(), pct);

    //Pneumatics
        if (Controller1.ButtonUp.pressing()) {
            Wings1.set(true);
            Wings2.set(true);
        }

        if (Controller1.ButtonLeft.pressing()){

          Wings1.set(true);
        }

        if (Controller1.ButtonRight.pressing())
        {
          Wings2.set(true);
        }
        }
        if (Controller1.ButtonDown.pressing()) {
            Wings1.set(false);
            Wings2.set(false);
        }

        if (Controller1.ButtonA.pressing())
        {
          Flywheel.spin(forward, 50, pct);
          shooter.spin(forward, 50, pct);
        }
        else if (Controller1.ButtonB.pressing())
        {
          Flywheel.spin(forward, 0, pct);
          shooter.spin(forward, 0, pct);
        }

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }

void shootCatapult(int speed)
{
    // Arm the catapult
    motor(catapultMotor) = speed;

    // Wait for the catapult to reach the desired position
    wait(1000, msec);  // Adjust the time based on the actual behavior of your catapult

    // Fire the catapult by stopping the motor
    motor{shooter} = 0;
}

void retractCatapult(int speed)
{
    // Retract the catapult
    motor{shooter} = -speed;

    // Wait for the catapult to reach the retracted position
    wait(1000, msec);  // Adjust the time based on the actual behavior of your catapult

    // Stop the motor
    motor{shooter} = 0;
}

void shooter_loop()
{
    // Set a default speed for the catapult motor
    int catapultSpeed = 100;

    // Run the catapult sequence in a loop
    while (true)
    {
        // Shoot the catapult
        shootCatapult(catapultSpeed);

        // Add any additional logic or tasks as needed
        // For example, you might want to add a delay before retracting the catapult

        // Retract the catapult
        retractCatapult(catapultSpeed);

        // Add any additional logic or tasks as needed
        // For example, you might want to add a delay before the next shot
    }
}



//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  //Competition.autonomous(autonomous);
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
